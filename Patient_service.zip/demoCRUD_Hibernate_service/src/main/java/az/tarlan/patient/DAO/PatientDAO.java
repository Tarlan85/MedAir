package az.tarlan.patient.DAO;

import az.tarlan.patient.entity.Patient;

import java.util.List;

public interface PatientDAO {
    public List<Patient> findAll();

    public Patient findById(int theId);

    public List<Patient> findByFirstName(Patient patient);

    public void save(Patient thePatient);

    public void deleteById(int theId);
}