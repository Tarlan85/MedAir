package az.tarlan.patient.entity;

import javax.persistence.*;

@Entity
@Table(name="patient")

public class Patient {
    //define field
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private int id;

    @Column(name="first_name")
    private String firstName;

    @Column(name="last_name")
    private String lastName;

    @Column(name="mob_num")
    private String telNumber;

    @Column(name="born")
    private String born;

    @Column(name="life")
    private String life;

    @Column(name="age")
    private int age;
    //define constructor
    public Patient(){

    }

    public Patient(int id, String firstName, String lastName, String telNumber, String born, String life,int age) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.telNumber = telNumber;
        this.born = born;
        this.life = life;
        this.age=age;
    }


    //define getter/setter

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMobNumber() {
        return telNumber;
    }

    public String getBorn() {
        return born;
    }

    public String getLife() {
        return life;
    }
    public int getAge() {
        return age;
    }

    public void setMobNumber(String mobNumber) {
        this.telNumber = mobNumber;
    }

    public void setBorn(String born) {
        this.born = born;
    }

    public void setLife(String life) {
        this.life = life;
    }
    public void setAge(int age) {
        this.age = age;
    }
//define toString



    @Override
    public String toString() {
        return "Patient{" +
                "id=" + id +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", mobNumber='" + telNumber + '\'' +
                ", born='" + born + '\'' +
                ", life='" + life + '\'' +
                ", age='" + age + '\'' +
                '}';
    }

}
