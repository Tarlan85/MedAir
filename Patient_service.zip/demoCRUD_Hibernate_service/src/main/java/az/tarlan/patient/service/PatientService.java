package az.tarlan.patient.service;

import az.tarlan.patient.entity.Patient;

import java.util.List;

public interface PatientService {

    public List<Patient> findAll();

    public Patient findById(int theId);

    public List<Patient> findByName(Patient patient);

    public void save(Patient thePatient);

    public void deleteById(int theId);
}