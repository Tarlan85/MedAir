package az.tarlan.patient.DAO;

import az.tarlan.patient.entity.Patient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.List;
@Repository
public class PatientDAOJPAImpl implements PatientDAO {
    int k=0;
    private EntityManager entityManager;
    @Autowired
    public PatientDAOJPAImpl(EntityManager theEntityManager) {
        entityManager = theEntityManager;
    }

    @Override
    public List<Patient> findAll() {
        //create a query
        Query theQuery=entityManager.createQuery("from Patient");
        //execute query and get result list
        List<Patient> patients =theQuery.getResultList();
        //return the result
        return patients;
    }

    @Override
    public Patient findById(int theId) {
        //get patient
        Patient thePatient =entityManager.find(Patient.class,theId);
        //return result
        return thePatient;
    }
    private String sql_concat(String tableName,String param){
        String sql="";

        if (param!=null){
            if( !param.equals(""))
            if (k == 0){
                sql=sql+ tableName+"='"+param+"'";
                k++;}
            else    sql=sql+" and "+tableName+"='"+param+"'";
        }
        return sql;
    }
    @Override
    public List<Patient> findByFirstName(Patient patient) {
        k=0;
        String sql="";
        String theFirstName=patient.getFirstName();
        String theLastName=patient.getLastName();
        String telNumber=patient.getMobNumber();
        String born=patient.getBorn() ;
        String life=patient.getLife() ;
        String age=Integer.toString(patient.getAge()) ;
        sql=sql_concat("first_name",theFirstName);
        sql=sql+sql_concat("last_name",theLastName);
        sql=sql+sql_concat("mob_num",telNumber);
        sql=sql+sql_concat("born",born);
        sql=sql+sql_concat("life",life);
        sql=sql+sql_concat("age",age);

        System.out.println("+++++++++++++++++++++++++++++");
        System.out.println("sql==FROM Patient where "+sql);
        Query theQuery=entityManager.createQuery("FROM Patient where "+sql);
        List<Patient> patients =theQuery.getResultList();
        System.out.println(patients.toString());
        //execute query and get result list
            if (patients.toString().equals("[]")) patients= null;
        k=0;
        return patients;
    }

    @Override
    public void save(Patient thePatient) {

        Patient dbPatient =entityManager.merge(thePatient);
        //update  with id in db ... so we can get generation id for save / insert
        thePatient.setId(dbPatient.getId());
    }

    @Override
    public void deleteById(int theId) {
        //delete  object with primary key
        Query theQuery=entityManager.createQuery("delete from Patient where id=:patientId");
        theQuery.setParameter("patientId",theId);
        theQuery.executeUpdate();
    }
}