package az.tarlan.patient.rest;

import az.tarlan.patient.entity.Patient;
import az.tarlan.patient.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class PatientRestController {
    private PatientService patientService;
    //quick and dirty:inject employee dao(use constructor injection )
    @Autowired
    public PatientRestController(PatientService thePatientService){
        patientService = thePatientService;
    }

    @GetMapping("/patients")
    public List<Patient> findAll(){
        System.out.println("findAll");
        return patientService.findAll();

    }
    @GetMapping("/patients/{patientId}")
    public Patient getPatientById(@PathVariable int patientId){
        Patient thePatient = patientService.findById(patientId);
        if(thePatient ==null){
            throw new RuntimeException("Patient id not found - "+patientId);
        }
    return thePatient;
    }

    @GetMapping("/patients/search")
//    @GetMapping("/patients/search/name={theFirstName}&secName={theLastName}&telNumber={telNumber}")
//    public List<Patient> getPatientByName(@PathVariable String theFirstName,@PathVariable String theLastName,@PathVariable String telNumber ){
    public List<Patient> getPatientByName(@RequestBody Patient patient){

        if(patientService.findByName(patient) ==null){
            throw new RuntimeException("Patient  not found - "+patient.toString());
        }
        return patientService.findByName(patient);
    }

    @PostMapping("/patients")
    public Patient addPatient(@RequestBody Patient thePatient){
        //also, just  in case  the pass an id  in JSON ... set id to 0
        //this is to force a save of new item ... instead of update
        thePatient.setId(0);
        patientService.save(thePatient);
        return thePatient;
    }


    @PutMapping("/patients")
    public Patient updatePatient(@RequestBody Patient thePatient){
        patientService.save(thePatient);
        return thePatient;
    }


    @DeleteMapping("/patients/{patientId}")
    public String deletePatient(@PathVariable int patientId){
        Patient tempPatient = patientService.findById(patientId);
        //throw  exception if null
        if(tempPatient ==null)
            throw new RuntimeException("Patient Id not found - "+patientId);
        patientService.deleteById(patientId);
        return "Delete patient id - "+patientId;
    }
}
